import React, { useState } from 'react';
import { SafeAreaView } from 'react-native';
import ToDoForm from './components/ToDoForm';
import ToDoList from './components/ToDoList';

export default function App() {
    const firstTasks = [
        'Do laundry',
        'Go to the gym',
        'Walk the dog'
    ];

    const [todos, setTodos] = useState(firstTasks);

    const addTodo = (newTodo) => {
        setTodos([...todos, newTodo]);
    };

    return (
        <SafeAreaView>
            <ToDoList tasks={todos} />
            <ToDoForm addTodo={addTodo} />
        </SafeAreaView>
    );
}

